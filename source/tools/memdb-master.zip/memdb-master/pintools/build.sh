# Build libdebug
make -f Makefile.libdebug

# Build the Pintools
make


